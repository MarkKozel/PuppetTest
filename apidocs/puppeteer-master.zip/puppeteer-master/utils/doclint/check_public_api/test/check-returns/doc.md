### class: Foo

#### foo.asyncFunction()

#### foo.return42()

#### foo.returnNothing()
- returns: <[number]>

#### foo.www()
- returns <[string]>
